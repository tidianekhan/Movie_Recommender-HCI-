1. Use case description\

The aim of our project is to create a recommender system for movies. This recommender system will be largely based on symbolic AI in particular using Sparql queries. There are a variety of ways the user will be able to interact with the movie recommender, with the user having the ability to take an active role in selecting a movie i.e. by filtering the options by a preferred actor, director or even genre. The user can also choose to take more of a passive role in choosing the movie they want to watch, for example we could implement a 'shuffle' option allowing the user to choose a random movie. Another possibility is choosing the language of a preferred film, as some users will not be English speakers or may even want to watch foreign language films. Finally, the relative interest of the user in films may come into play, with some users being more comfortable watching popular blockbusters and others preferring to indulge in hidden gems. This desire for lesser known films could be added by adding an option to limit the box office earnings of the recommended system below a certain amount. 

2. Personas
Joe Buck:
=Stock broker
=not a tech savvy guy, very comfortable with tech he is used to, not keen on learning new tech
=prefers a simple and intuitive design 
=Solution: simple UI, clear layout, properly marked instructions/buttons

Sarah Harding
=zoologist
=budding cinephile, looking to expand her movie palate
=wants a recommender with both blockbusters but also hidden/less popular gems
=Solution: provide a large variety of movies with many filter options 

3. Scenario 
Sarah Harding, after a long day of work, has come home to her apartment and wants to curl up on her sofa and watch a horror movie. She, however, does not want to watch any old blockbuster horror movie, rather she wants to watch a hidden gem of a film. Unfortunately, Sarah is not sure what movie to watch, so she loads up her favorite movie recommender (ours) and chooses from a drop down list of genres including but not limited to: Horror, Fantasy, Action, Thriller, Documentary, Family etc. From this list she chooses the option 'Horror' which then shows a list of horror movies. After this she navigates to the filter drop down list which provides a variety of options including preferred actors, directors, language, lesser known films etc. and selects lesser known films. She doesn't select any of the other filters as she has no preference for actors, directors, and language. After this the page reloads and produces a list of films. She then picks the film 'Barbarian' and begins to watch. She thoroughly enjoys the film. 

4. Design decisions
The design layout we incorporated in our mockup is simplistic and not overwhelming. When choosing a movie to watch, users usually don\'92t want to spend too much time deciding. For that reason we also made it possible for all categories to have a 'No preference' option, so that the user has complete freedom over which filters to apply and which to leave out to be chosen randomly. For filters that have a high number of options we added a sorting option, allowing users to sort through the names/languages in their preferred order and also a search bar, in case the user already has a specific name/language in mind. In the final result recommendation, we wanted to implement the movie poster as well as its title and release date, to give the user a sense of the overarching theme of the movie. 

5. Implementation decisions
In the implementation process, a decision was made to implement the application using Tkinter module in python rather than Javascript and Sparql for queries due to time constraints and lack of knowledge in Javascript and Sparql. 
