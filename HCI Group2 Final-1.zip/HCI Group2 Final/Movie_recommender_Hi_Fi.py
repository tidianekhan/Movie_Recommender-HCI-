from tkinter import *

TK_SILENCE_DEPRECATION=1
def raise_frame(frame):
    frame.tkraise()

root = Tk()  # create root window
root.title("Movie Recommender")

f1 =  Frame(root, padx=150, pady=150, bg="light blue")
f2 =  Frame(root, bg="light blue")
f3 =  Frame(root, bg="light blue")
f4 =  Frame(root, bg="light blue")
f5 =  Frame(root, bg="light blue")
f6 =  Frame(root, bg="light blue")
f7 =  Frame(root, bg="light blue")

for frame in (f1, f2, f3, f4, f5, f6, f7):
    frame.grid(row=0, column=0, sticky='news')

#Main page
Label(f1, text='Filters:', bg="light blue", font=("Arial", 20), height = 5).pack()
Button(f1, text='Genres',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f2)).pack()
Label(f1, text=' ', bg="light blue").pack()
Button(f1, text='Preferred Actors',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f3)).pack()
Label(f1, text=' ', bg="light blue").pack()
Button(f1, text='Directors',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f4)).pack()
Label(f1, text=' ', bg="light blue").pack()
Button(f1, text='Languages',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f5)).pack()
Label(f1, text=' ', bg="light blue").pack()
Button(f1, text='Popularity',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f6)).pack()
Label(f1, text=' ', bg="light blue").pack()
Button(f1, text='Recommend',bg="white smoke", activebackground="red", activeforeground="red", font=("Arial", 15), background="#b7f731", command=lambda:raise_frame(f7)).pack()

#Genre page
Label(f2, text='Genres:', bg="light blue", font=("Arial", 20), height = 5).pack()
Action = IntVar()
Horror = IntVar()
Family = IntVar()
Comedy = IntVar()
Checkbutton(f2, variable = Action, text='Action', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f2, text=' ', bg="light blue").pack()
Checkbutton(f2, variable = Horror, text='Horror', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f2, text=' ', bg="light blue").pack()
Checkbutton(f2, variable = Family, text='Family', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f2, text=' ', bg="light blue").pack()
Checkbutton(f2, variable = Comedy, text='Comedy', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f2, text=' ', bg="light blue").pack()
Button(f2, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()

#Preferred Actors page
Label(f3, text='Preferred Actors:', bg="light blue", font=("Arial", 20), height = 5).pack()
Lee_Aaker = IntVar()
Bud_Abbott = IntVar()
John_Abbott= IntVar()
Walter_Abel = IntVar()
Checkbutton(f3, variable = Lee_Aaker, text='Lee Aaker', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f3, text=' ', bg="light blue").pack()
Checkbutton(f3, variable = Bud_Abbott, text='Bud Abbott', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f3, text=' ', bg="light blue").pack()
Checkbutton(f3, variable = John_Abbott, text='John Abbott', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f3, text=' ', bg="light blue").pack()
Checkbutton(f3, variable = Walter_Abel, text='Walter Abel', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f3, text=' ', bg="light blue").pack()
Button(f3, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()

#Directors page
Label(f4, text='Directors:', bg="light blue", font=("Arial", 20), height = 5).pack()
Dodo_Abashidze = IntVar()
George_Abbott = IntVar()
Norman_Abbott= IntVar()
Phil_Abraham = IntVar()
Checkbutton(f4, variable = Dodo_Abashidze, text='Dodo Abashidze', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f4, text=' ', bg="light blue").pack()
Checkbutton(f4, variable = George_Abbott, text='George Abbott', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f4, text=' ', bg="light blue").pack()
Checkbutton(f4, variable = Norman_Abbott, text='Norman Abbott', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f4, text=' ', bg="light blue").pack()
Checkbutton(f4, variable = Phil_Abraham, text='Phil Abraham', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f4, text=' ', bg="light blue").pack()
Button(f4, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()

#Languages page
Label(f5, text='Languages:', bg="light blue", font=("Arial", 20), height = 5).pack()
English = IntVar()
Dutch = IntVar()
Spanish = IntVar()
Italian = IntVar()
French = IntVar()
Checkbutton(f5, variable = English, text='English', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f5, text=' ', bg="light blue").pack()
Checkbutton(f5, variable = Dutch, text='Dutch', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f5, text=' ', bg="light blue").pack()
Checkbutton(f5, variable = Spanish, text='Spanish', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f5, text=' ', bg="light blue").pack()
Checkbutton(f5, variable = Italian, text='Italian', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f5, text=' ', bg="light blue").pack()
Checkbutton(f5, variable = French, text='French', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f5, text=' ', bg="light blue").pack()
Button(f5, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()

#Popularity page
Label(f6, text='Popularity:', bg="light blue", font=("Arial", 20), height = 5).pack()
Trending_now = IntVar()
Blockbusters = IntVar()
Hidden_gems = IntVar()
Critically_acclaimed = IntVar()
Checkbutton(f6, variable = Trending_now, text='Trending_now', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f6, text=' ', bg="light blue").pack()
Checkbutton(f6, variable = Blockbusters, text='Blockbusters', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f6, text=' ', bg="light blue").pack()
Checkbutton(f6, variable = Hidden_gems, text='Hidden gems', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f6, text=' ', bg="light blue").pack()
Checkbutton(f6, variable = Critically_acclaimed, text='Critically acclaimed', bg="light blue", font=("Arial", 15), onvalue=1, offvalue=0).pack()
Label(f6, text=' ', bg="light blue").pack()
Button(f6, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()

#Recommendation page
Label(f7, text='Recommendation', bg="light blue", font=("Arial", 20), height = 5).pack()
Label(f7, text='Movie title', bg="light blue", font=("Arial", 30)).pack()
Label(f7, text='Movie description', bg="light blue", font=("Arial", 15), height = 5).pack()
Button(f7, text='back',bg="orange", activebackground="red", activeforeground="red", font=("Arial", 15), command=lambda:raise_frame(f1)).pack()


raise_frame(f1)
root.mainloop()